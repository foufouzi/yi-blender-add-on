# SPDX-License-Identifier: GPL-3.0-or-later
"""Yi_anim_selection_set - personal pose bone selection sets.

Sets are stored per user (not inside the .blend), keyed by rig name,
so every animator keeps their own sets and they follow across shots.
"""

import json
import os
import re
import shutil
import time

import bpy
import rna_keymap_ui

FILE_NAME = "selection_sets.json"
LEGACY_PROP_KEY = "anim_sel_sets"  # v1.0.0 stored sets on the object
COLOR_KEY = "__colors__"  # {rig_key: {set_name: "01".."20"}}
COLOR_COUNT = 20
VISIBILITY_KEY = "__visibility__"  # {rig_key: {set_name: bool}}
ORDER_KEY = "__order__"  # {rig_key: [set_name, ...]}

_cache = {}
_solo_states = {}  # {object_pointer: (object, {bone_name: original_hidden_state})}
_last_set_click = None  # ((object_pointer, set_name), timestamp)


def get_solo_state(obj):
    """Return this armature's active Solo snapshot, if any."""
    if obj is None:
        return None
    state = _solo_states.get(obj.as_pointer())
    return state if state is not None and state[0] == obj else None


def is_set_solo_active(obj, set_name):
    """Return whether this selection set is the active Solo target."""
    state = get_solo_state(obj)
    return state is not None and state[1] == set_name


def solo_bones(obj, bone_names, set_name=None):
    """Isolate named bones, preserving the original visibility snapshot."""
    pointer = obj.as_pointer()
    state = get_solo_state(obj)
    if state is None:
        hidden_states = {bone.name: bone.hide for bone in obj.data.bones}
    else:
        hidden_states = state[2]

    selected = set(bone_names)
    _solo_states[pointer] = (obj, set_name, hidden_states)
    for bone in obj.data.bones:
        bone.hide = bone.name not in selected


def restore_solo(obj):
    """Restore the bone visibility captured before Solo was enabled."""
    if obj is None:
        return False
    pointer = obj.as_pointer()
    state = _solo_states.get(pointer)
    if state is None or state[0] != obj:
        return False

    hidden_states = state[2]
    for name, was_hidden in hidden_states.items():
        bone = obj.data.bones.get(name)
        if bone is not None:
            bone.hide = was_hidden
    _solo_states.pop(pointer, None)
    return True


def restore_all_solo_states():
    """Restore active Solo visibility snapshots before the add-on unregisters."""
    for state in list(_solo_states.values()):
        try:
            restore_solo(state[0])
        except (ReferenceError, RuntimeError):
            pass
    _solo_states.clear()


# ------------------------------------------------------------------
# Storage (per-user JSON file)
# ------------------------------------------------------------------
def storage_dir():
    return bpy.utils.extension_path_user(__package__, path="", create=True)


def storage_file():
    return os.path.join(storage_dir(), FILE_NAME)


def read_file():
    path = storage_file()
    if not os.path.isfile(path):
        return {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def write_file(data):
    path = storage_file()
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False, sort_keys=True)
    os.replace(tmp, path)


OLD_PACKAGE_ID = "anim_selection_sets"  # versions 1.x


def migrate_old_storage():
    """Copy sets from the 1.x add-on (old id) the first time 2.x runs."""
    new_path = storage_file()
    if os.path.isfile(new_path):
        return
    parent = os.path.dirname(os.path.normpath(storage_dir()))
    old_path = os.path.join(parent, OLD_PACKAGE_ID, FILE_NAME)
    if os.path.isfile(old_path):
        try:
            shutil.copyfile(old_path, new_path)
            print(f"[Yi_anim_selection_set] Migrated sets from {old_path}")
        except OSError as exc:
            print(f"[Yi_anim_selection_set] Migration failed: {exc}")


def reload_cache():
    _cache.clear()
    _cache.update(read_file())


def update_data(func):
    """Re-read from disk, apply func(data), then save.

    Re-reading first avoids overwriting changes made by another
    Blender session that is open at the same time.
    """
    data = read_file()
    func(data)
    write_file(data)
    _cache.clear()
    _cache.update(data)


def update_rig_sets(key, func):
    def apply(data):
        sets = data.get(key, {})
        func(sets)
        if sets:
            data[key] = sets
        else:
            data.pop(key, None)

    update_data(apply)


def set_color_in_data(data, key, name, color):
    all_colors = data.setdefault(COLOR_KEY, {})
    colors = all_colors.setdefault(key, {})
    if color:
        colors[name] = color
    else:
        colors.pop(name, None)
    if not colors:
        all_colors.pop(key, None)
    if not all_colors:
        data.pop(COLOR_KEY, None)


# ------------------------------------------------------------------
# Rig identification
# ------------------------------------------------------------------
_SUFFIX_RE = re.compile(r"\.\d{3}$")


def rig_key(obj):
    """Stable name for a rig across shots (handles link / override / .001)."""
    arm = obj.data
    override = getattr(arm, "override_library", None)
    if override is not None and override.reference is not None:
        arm = override.reference
    return _SUFFIX_RE.sub("", arm.name)


def get_sets(obj):
    return _cache.get(rig_key(obj), {})


def get_ordered_set_names(obj):
    """Return saved order, falling back to alphabetical order for old data."""
    sets = get_sets(obj)
    saved = _cache.get(ORDER_KEY, {}).get(rig_key(obj), [])
    ordered = [name for name in saved if name in sets]
    ordered.extend(sorted(set(sets) - set(ordered)))
    return ordered


def get_color(obj, name):
    return _cache.get(COLOR_KEY, {}).get(rig_key(obj), {}).get(name, "")


def is_set_visible(obj, name):
    return _cache.get(VISIBILITY_KEY, {}).get(rig_key(obj), {}).get(name, True)


def color_icon(color):
    return f"COLORSET_{color}_VEC" if color else 'RADIOBUT_OFF'


def is_pose_armature(context):
    obj = context.object
    return obj is not None and obj.type == 'ARMATURE' and context.mode == 'POSE'


# ------------------------------------------------------------------
# Operators
# ------------------------------------------------------------------
class ANIM_OT_yi_selset_add(bpy.types.Operator):
    """Save selected pose bones as a selection set"""
    bl_idname = "anim.yi_selset_add"
    bl_label = "Add Selection Set"
    bl_options = {'REGISTER'}

    set_name: bpy.props.StringProperty(name="Name", default="NewSet")

    @classmethod
    def poll(cls, context):
        return is_pose_armature(context) and bool(context.selected_pose_bones)

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        obj = context.object
        name = self.set_name.strip()
        if not name:
            self.report({'WARNING'}, "Set name is empty")
            return {'CANCELLED'}

        bones = [pb.name for pb in context.selected_pose_bones if pb.id_data == obj]
        overwrite = name in get_sets(obj)

        def apply(sets):
            sets[name] = bones

        key = rig_key(obj)
        update_rig_sets(key, apply)

        def update_order(data):
            sets = data.get(key, {})
            all_orders = data.setdefault(ORDER_KEY, {})
            saved = all_orders.get(key)
            if saved is None:
                ordered = sorted(set(sets) - ({name} if not overwrite else set()))
            else:
                ordered = [item for item in saved if item in sets]
                ordered.extend(sorted(set(sets) - set(ordered)))
            if not overwrite and name in ordered:
                ordered.remove(name)
                ordered.append(name)
            all_orders[key] = ordered

        update_data(update_order)
        verb = "Updated" if overwrite else "Created"
        self.report({'INFO'}, f"{verb} set '{name}' ({len(bones)} bones)")
        return {'FINISHED'}


class ANIM_OT_yi_selset_rename(bpy.types.Operator):
    """Rename a selection set while preserving its bones and metadata"""
    bl_idname = "anim.yi_selset_rename"
    bl_label = "Rename Selection Set"
    bl_options = {'REGISTER'}

    set_name: bpy.props.StringProperty(name="Current Name")
    new_name: bpy.props.StringProperty(name="New Name")

    @classmethod
    def poll(cls, context):
        obj = context.object
        return obj is not None and obj.type == 'ARMATURE'

    def invoke(self, context, event):
        self.new_name = self.set_name
        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        obj = context.object
        key = rig_key(obj)
        old_name = self.set_name
        new_name = self.new_name.strip()
        if not new_name:
            self.report({'WARNING'}, "Set name is empty")
            return {'CANCELLED'}

        result = {}

        def apply(data):
            sets = data.get(key, {})
            if old_name not in sets:
                result["error"] = f"Set '{old_name}' not found"
                return
            if new_name != old_name and new_name in sets:
                result["error"] = f"A set named '{new_name}' already exists"
                return
            if new_name == old_name:
                result["unchanged"] = True
                return

            sets[new_name] = sets.pop(old_name)
            data[key] = sets

            for metadata_key in (COLOR_KEY, VISIBILITY_KEY):
                all_metadata = data.get(metadata_key, {})
                rig_metadata = all_metadata.get(key, {})
                if old_name in rig_metadata:
                    rig_metadata[new_name] = rig_metadata.pop(old_name)
                if not rig_metadata:
                    all_metadata.pop(key, None)
                if not all_metadata:
                    data.pop(metadata_key, None)

            all_orders = data.get(ORDER_KEY, {})
            rig_order = all_orders.get(key, [])
            if old_name in rig_order:
                rig_order[rig_order.index(old_name)] = new_name
            if not rig_order:
                all_orders.pop(key, None)
            if not all_orders:
                data.pop(ORDER_KEY, None)

        update_data(apply)
        if "error" in result:
            self.report({'WARNING'}, result["error"])
            return {'CANCELLED'}
        if not result.get("unchanged"):
            self.report({'INFO'}, f"Renamed '{old_name}' to '{new_name}'")
        if context.area:
            context.area.tag_redraw()
        return {'FINISHED'}


class ANIM_OT_yi_selset_select(bpy.types.Operator):
    """Click: select set / Shift+Click: add to selection"""
    bl_idname = "anim.yi_selset_select"
    bl_label = "Select Set"
    bl_options = {'REGISTER', 'UNDO'}

    set_name: bpy.props.StringProperty()
    extend: bpy.props.BoolProperty(name="Extend", default=False)

    @classmethod
    def poll(cls, context):
        return is_pose_armature(context)

    def invoke(self, context, event):
        global _last_set_click
        click_key = (context.object.as_pointer(), self.set_name)
        now = time.monotonic()
        if (_last_set_click is not None
                and _last_set_click[0] == click_key
                and now - _last_set_click[1] <= 0.5):
            _last_set_click = None
            return bpy.ops.anim.yi_selset_rename(
                'INVOKE_DEFAULT', set_name=self.set_name
            )

        _last_set_click = (click_key, now)
        self.extend = event.shift
        return self.execute(context)

    def execute(self, context):
        obj = context.object
        names = get_sets(obj).get(self.set_name)
        if names is None:
            self.report({'WARNING'}, f"Set '{self.set_name}' not found")
            return {'CANCELLED'}

        names = set(names)
        missing = names - set(obj.pose.bones.keys())
        last = None
        for pb in obj.pose.bones:
            in_set = pb.name in names
            if in_set or not self.extend:
                pb.bone.select = in_set
            if in_set:
                last = pb.bone

        if last is not None:
            obj.data.bones.active = last
        if missing:
            self.report({'WARNING'}, f"{len(missing)} bone(s) missing in rig")
        if context.area:
            context.area.tag_redraw()
        return {'FINISHED'}


class ANIM_OT_yi_selset_remove(bpy.types.Operator):
    """Remove this selection set"""
    bl_idname = "anim.yi_selset_remove"
    bl_label = "Remove Selection Set"
    bl_options = {'REGISTER'}

    set_name: bpy.props.StringProperty()

    @classmethod
    def poll(cls, context):
        obj = context.object
        return obj is not None and obj.type == 'ARMATURE'

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        name = self.set_name

        key = rig_key(context.object)

        def apply(data):
            sets = data.get(key, {})
            sets.pop(name, None)
            if sets:
                data[key] = sets
            else:
                data.pop(key, None)
            set_color_in_data(data, key, name, "")
            all_visibility = data.get(VISIBILITY_KEY, {})
            visibility = all_visibility.get(key, {})
            visibility.pop(name, None)
            if not visibility:
                all_visibility.pop(key, None)
            if not all_visibility:
                data.pop(VISIBILITY_KEY, None)

            all_orders = data.get(ORDER_KEY, {})
            rig_order = all_orders.get(key, [])
            if name in rig_order:
                rig_order.remove(name)
            if not rig_order:
                all_orders.pop(key, None)
            if not all_orders:
                data.pop(ORDER_KEY, None)

        update_data(apply)
        return {'FINISHED'}


class ANIM_OT_yi_selset_modify(bpy.types.Operator):
    """Add (+) or remove (-) the selected bones to/from this set"""
    bl_idname = "anim.yi_selset_modify"
    bl_label = "Modify Selection Set"
    bl_options = {'REGISTER'}

    set_name: bpy.props.StringProperty()
    mode: bpy.props.EnumProperty(
        items=[
            ('ADD', "Add", "Add selected bones to the set"),
            ('REMOVE', "Remove", "Remove selected bones from the set"),
        ],
        default='ADD',
    )

    @classmethod
    def poll(cls, context):
        return is_pose_armature(context) and bool(context.selected_pose_bones)

    @classmethod
    def description(cls, context, props):
        if props.mode == 'ADD':
            return "Add selected bones to this set"
        return "Remove selected bones from this set"

    def execute(self, context):
        obj = context.object
        name = self.set_name
        if name not in get_sets(obj):
            self.report({'WARNING'}, f"Set '{name}' not found")
            return {'CANCELLED'}

        selected = [pb.name for pb in context.selected_pose_bones if pb.id_data == obj]
        result = {}

        def apply(sets):
            current = list(sets.get(name, []))
            if self.mode == 'ADD':
                new = [b for b in selected if b not in current]
                current.extend(new)
                result["count"] = len(new)
            else:
                drop = set(selected)
                result["count"] = sum(1 for b in current if b in drop)
                current = [b for b in current if b not in drop]
            sets[name] = current

        update_rig_sets(rig_key(obj), apply)

        count = result.get("count", 0)
        remaining = len(get_sets(obj).get(name, []))
        if self.mode == 'ADD':
            msg = f"Added {count} bone(s) to '{name}' ({remaining} total)"
        else:
            msg = f"Removed {count} bone(s) from '{name}' ({remaining} left)"
        self.report({'INFO'}, msg)
        if remaining == 0:
            self.report({'WARNING'}, f"Set '{name}' is now empty")
        return {'FINISHED'}


class ANIM_OT_yi_selset_move(bpy.types.Operator):
    """Move a selection set up or down in the list"""
    bl_idname = "anim.yi_selset_move"
    bl_label = "Move Selection Set"
    bl_options = {'REGISTER'}

    set_name: bpy.props.StringProperty()
    direction: bpy.props.EnumProperty(
        items=[
            ('UP', "Up", "Move this set up one position"),
            ('DOWN', "Down", "Move this set down one position"),
        ],
        default='UP',
    )

    @classmethod
    def poll(cls, context):
        return is_pose_armature(context)

    def execute(self, context):
        obj = context.object
        key = rig_key(obj)
        ordered = get_ordered_set_names(obj)
        if self.set_name not in ordered:
            return {'CANCELLED'}

        index = ordered.index(self.set_name)
        target = index - 1 if self.direction == 'UP' else index + 1
        if target < 0 or target >= len(ordered):
            return {'CANCELLED'}
        ordered[index], ordered[target] = ordered[target], ordered[index]

        def apply(data):
            sets = data.get(key, {})
            current = [name for name in ordered if name in sets]
            current.extend(sorted(set(sets) - set(current)))
            if current:
                data.setdefault(ORDER_KEY, {})[key] = current
            else:
                all_orders = data.get(ORDER_KEY, {})
                all_orders.pop(key, None)
                if not all_orders:
                    data.pop(ORDER_KEY, None)

        update_data(apply)
        if context.area:
            context.area.tag_redraw()
        return {'FINISHED'}


class ANIM_OT_yi_selset_color(bpy.types.Operator):
    """Set the color tag of this selection set"""
    bl_idname = "anim.yi_selset_color"
    bl_label = "Set Selection Set Color"
    bl_options = {'REGISTER'}

    set_name: bpy.props.StringProperty()
    color: bpy.props.StringProperty()  # "01".."20", "" = no color

    @classmethod
    def poll(cls, context):
        obj = context.object
        return obj is not None and obj.type == 'ARMATURE'

    def execute(self, context):
        key = rig_key(context.object)
        name, color = self.set_name, self.color

        def apply(data):
            set_color_in_data(data, key, name, color)

        update_data(apply)
        return {'FINISHED'}


class ANIM_OT_yi_selset_color_pick(bpy.types.Operator):
    """Pick a color for this selection set"""
    bl_idname = "anim.yi_selset_color_pick"
    bl_label = "Pick Color"

    set_name: bpy.props.StringProperty()

    @classmethod
    def poll(cls, context):
        obj = context.object
        return obj is not None and obj.type == 'ARMATURE'

    def invoke(self, context, event):
        name = self.set_name

        def draw(menu, _context):
            layout = menu.layout
            grid = layout.grid_flow(row_major=True, columns=5,
                                    even_columns=True, align=True)
            for i in range(1, COLOR_COUNT + 1):
                code = f"{i:02d}"
                op = grid.operator(ANIM_OT_yi_selset_color.bl_idname,
                                   text="", icon=color_icon(code))
                op.set_name = name
                op.color = code
            layout.separator()
            op = layout.operator(ANIM_OT_yi_selset_color.bl_idname,
                                 text="No Color", icon='X')
            op.set_name = name
            op.color = ""

        context.window_manager.popup_menu(draw, title=f"Color: {name}")
        return {'FINISHED'}

    def execute(self, context):
        return {'CANCELLED'}


class ANIM_OT_yi_selset_visibility(bpy.types.Operator):
    """Show or hide the bones in this selection set"""
    bl_idname = "anim.yi_selset_visibility"
    bl_label = "Toggle Selection Set Visibility"
    bl_options = {'REGISTER', 'UNDO'}

    set_name: bpy.props.StringProperty()

    @classmethod
    def poll(cls, context):
        return is_pose_armature(context)

    def execute(self, context):
        obj = context.object
        key = rig_key(obj)
        names = get_sets(obj).get(self.set_name)
        if names is None:
            self.report({'WARNING'}, f"Set '{self.set_name}' not found")
            return {'CANCELLED'}

        visible_now = is_set_visible(obj, self.set_name)
        make_visible = not visible_now
        found = 0
        for name in names:
            bone = obj.data.bones.get(name)
            if bone is not None:
                bone.hide = not make_visible
                found += 1

        def apply(data):
            states = data.setdefault(VISIBILITY_KEY, {})
            rig_states = states.setdefault(key, {})
            # Default is visible; omit visible entries to keep the file compact.
            if make_visible:
                rig_states.pop(self.set_name, None)
            else:
                rig_states[self.set_name] = False
            if not rig_states:
                states.pop(key, None)
            if not states:
                data.pop(VISIBILITY_KEY, None)

        update_data(apply)
        if found < len(names):
            self.report({'WARNING'}, f"{len(names) - found} bone(s) not found")
        if context.area:
            context.area.tag_redraw()
        return {'FINISHED'}


class ANIM_OT_yi_selset_solo_set(bpy.types.Operator):
    """Solo the bones in this selection set"""
    bl_idname = "anim.yi_selset_solo_set"
    bl_label = "Solo Selection Set"
    bl_options = {'REGISTER'}

    set_name: bpy.props.StringProperty()

    @classmethod
    def poll(cls, context):
        return is_pose_armature(context)

    def execute(self, context):
        obj = context.object
        names = get_sets(obj).get(self.set_name)
        if names is None:
            self.report({'WARNING'}, f"Set '{self.set_name}' not found")
            return {'CANCELLED'}

        if is_set_solo_active(obj, self.set_name):
            restore_solo(obj)
            self.report({'INFO'}, f"Solo off: '{self.set_name}'")
        else:
            found = [name for name in names if obj.data.bones.get(name) is not None]
            if not found:
                self.report({'WARNING'}, f"Set '{self.set_name}' has no bones in this rig")
                return {'CANCELLED'}
            solo_bones(obj, found, self.set_name)
            self.report({'INFO'}, f"Solo on: '{self.set_name}'")

        if context.area:
            context.area.tag_redraw()
        return {'FINISHED'}


class ANIM_OT_yi_selset_reload(bpy.types.Operator):
    """Reload selection sets from your personal file"""
    bl_idname = "anim.yi_selset_reload"
    bl_label = "Reload Selection Sets"

    def execute(self, context):
        reload_cache()
        return {'FINISHED'}


class ANIM_OT_yi_selset_migrate(bpy.types.Operator):
    """Move sets saved inside this .blend (v1.0.0) into your personal file"""
    bl_idname = "anim.yi_selset_migrate"
    bl_label = "Import Sets From This File"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.object
        return obj is not None and LEGACY_PROP_KEY in obj

    def execute(self, context):
        obj = context.object
        try:
            legacy = json.loads(obj[LEGACY_PROP_KEY])
        except (TypeError, ValueError):
            legacy = {}

        def apply(sets):
            for name, bones in legacy.items():
                sets.setdefault(name, bones)

        update_rig_sets(rig_key(obj), apply)
        del obj[LEGACY_PROP_KEY]
        self.report({'INFO'}, f"Imported {len(legacy)} set(s)")
        return {'FINISHED'}


class ANIM_OT_yi_selset_open_folder(bpy.types.Operator):
    """Open the folder that stores your selection sets"""
    bl_idname = "anim.yi_selset_open_folder"
    bl_label = "Open Storage Folder"

    def execute(self, context):
        bpy.ops.wm.path_open(filepath=storage_dir())
        return {'FINISHED'}


# ------------------------------------------------------------------
# UI
# ------------------------------------------------------------------
def draw_strip_toggle(layout):
    layout.separator()
    layout.operator(
        "anim.yi_selset_strip_toggle",
        text="Open Set Strip Window",
        icon='WINDOW',
    )


def draw_selection_sets(layout, context, show_strip_toggle=False):
    """Shared UI for both the popup and the N sidebar panel."""
    obj = context.object

    if obj is None or obj.type != 'ARMATURE':
        layout.label(text="Select an armature", icon='INFO')
        return

    if LEGACY_PROP_KEY in obj:
        box = layout.box()
        box.label(text="Old sets found in this file", icon='ERROR')
        box.operator("anim.yi_selset_migrate", icon='IMPORT')

    if context.mode != 'POSE':
        layout.label(text="Enter Pose Mode to use", icon='INFO')
        return

    layout.label(text=f"Rig: {rig_key(obj)}", icon='ARMATURE_DATA')
    layout.operator("anim.yi_selset_add", icon='ADD')

    sets = get_sets(obj)
    if not sets:
        layout.label(text="No sets yet")
        if show_strip_toggle:
            draw_strip_toggle(layout)
        return

    col = layout.column(align=True)
    ordered_names = get_ordered_set_names(obj)
    for index, name in enumerate(ordered_names):
        row = col.row(align=True)
        solo = row.operator(
            "anim.yi_selset_solo_set",
            text="",
            icon='SOLO_ON' if is_set_solo_active(obj, name) else 'SOLO_OFF',
            emboss=False,
        )
        solo.set_name = name
        eye = row.operator("anim.yi_selset_visibility", text="",
                           icon='HIDE_OFF' if is_set_visible(obj, name) else 'HIDE_ON',
                           emboss=False)
        eye.set_name = name
        pick = row.operator("anim.yi_selset_color_pick", text="",
                            icon=color_icon(get_color(obj, name)),
                            emboss=False)
        pick.set_name = name
        op = row.operator("anim.yi_selset_select", text=name)
        op.set_name = name
        add = row.operator("anim.yi_selset_modify", text="", icon='ADD')
        add.set_name = name
        add.mode = 'ADD'
        sub = row.operator("anim.yi_selset_modify", text="", icon='REMOVE')
        sub.set_name = name
        sub.mode = 'REMOVE'
        row.separator()
        up_row = row.row(align=True)
        up_row.enabled = index > 0
        up = up_row.operator("anim.yi_selset_move", text="", icon='TRIA_UP',
                             emboss=False)
        up.set_name = name
        up.direction = 'UP'
        down_row = row.row(align=True)
        down_row.enabled = index < len(ordered_names) - 1
        down = down_row.operator("anim.yi_selset_move", text="", icon='TRIA_DOWN',
                                 emboss=False)
        down.set_name = name
        down.direction = 'DOWN'
        rm = row.operator("anim.yi_selset_remove", text="", icon='X')
        rm.set_name = name

    if show_strip_toggle:
        draw_strip_toggle(layout)


class ANIM_PT_yi_selset_popup(bpy.types.Panel):
    """Popup panel, shown at the mouse cursor"""
    bl_label = "Selection Sets"
    bl_idname = "ANIM_PT_yi_selset_popup"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'WINDOW'
    bl_ui_units_x = 12

    def draw(self, context):
        layout = self.layout
        header = layout.row(align=True)
        header.label(text="Selection Sets", icon='GROUP_BONE')
        header.operator("anim.yi_selset_reload", text="", icon='FILE_REFRESH')
        draw_selection_sets(layout, context)


class ANIM_PT_yi_selset_sidebar(bpy.types.Panel):
    """Full Selection Sets manager in the N-panel Item tab"""
    bl_label = "Selection Sets"
    bl_idname = "ANIM_PT_yi_selset_sidebar"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Item"

    def draw_header(self, context):
        self.layout.label(text="", icon='SOLO_ON')

    def draw_header_preset(self, context):
        self.layout.operator("anim.yi_selset_reload", text="",
                             icon='FILE_REFRESH', emboss=False)

    def draw(self, context):
        draw_selection_sets(self.layout, context, show_strip_toggle=True)


class ANIM_PT_yi_selset_strip_sidebar(bpy.types.Panel):
    """Name-only horizontal set strip for the duplicated 3D View window"""
    bl_label = "Set Strip"
    bl_idname = "ANIM_PT_yi_selset_strip_sidebar"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Item"
    bl_options = {'HIDE_HEADER'}

    def draw(self, context):
        layout = self.layout
        obj = context.object
        if not is_pose_armature(context):
            layout.label(text="Enter Pose Mode to use", icon='INFO')
            return

        row = layout.row(align=True)
        for name in get_ordered_set_names(obj):
            op = row.operator("anim.yi_selset_select", text=name)
            op.set_name = name
        if not get_sets(obj):
            layout.label(text="No sets yet")


class ANIM_OT_yi_selset_strip_toggle(bpy.types.Operator):
    """Open a separate 3D View window for the horizontal set strip"""
    bl_idname = "anim.yi_selset_strip_toggle"
    bl_label = "Open Set Strip Window"
    bl_description = "Duplicate this 3D View into a separate window; use its Set Strip sidebar tab"

    @classmethod
    def poll(cls, context):
        return context.area is not None and context.area.type == 'VIEW_3D'

    def execute(self, context):
        bpy.ops.screen.area_dupli('INVOKE_DEFAULT')
        return {'FINISHED'}


class ANIM_OT_yi_selset_popup(bpy.types.Operator):
    """Show the Selection Sets popup at the mouse cursor"""
    bl_idname = "anim.yi_selset_popup"
    bl_label = "Selection Sets"

    @classmethod
    def poll(cls, context):
        return context.area is not None and context.area.type == 'VIEW_3D'

    def execute(self, context):
        bpy.ops.wm.call_panel(name=ANIM_PT_yi_selset_popup.bl_idname, keep_open=True)
        return {'FINISHED'}


class ANIM_AP_yi_selset_prefs(bpy.types.AddonPreferences):
    bl_idname = __package__

    def draw(self, context):
        layout = self.layout
        layout.label(text="Sets are personal and stored outside .blend files:")
        layout.label(text=storage_file())
        layout.operator("anim.yi_selset_open_folder", icon='FILE_FOLDER')

        layout.separator()
        layout.label(text="Popup hotkey (Pose Mode):")
        kc = context.window_manager.keyconfigs.user
        km = kc.keymaps.get(KEYMAP_NAME)
        if km is None:
            return
        for kmi in km.keymap_items:
            if kmi.idname == ANIM_OT_yi_selset_popup.bl_idname:
                rna_keymap_ui.draw_kmi([], kc, km, kmi, layout, 0)
                break


# ------------------------------------------------------------------
# Registration
# ------------------------------------------------------------------
KEYMAP_NAME = "Pose"
_addon_keymaps = []

classes = (
    ANIM_OT_yi_selset_add,
    ANIM_OT_yi_selset_rename,
    ANIM_OT_yi_selset_select,
    ANIM_OT_yi_selset_remove,
    ANIM_OT_yi_selset_modify,
    ANIM_OT_yi_selset_move,
    ANIM_OT_yi_selset_color,
    ANIM_OT_yi_selset_color_pick,
    ANIM_OT_yi_selset_visibility,
    ANIM_OT_yi_selset_solo_set,
    ANIM_OT_yi_selset_reload,
    ANIM_OT_yi_selset_migrate,
    ANIM_OT_yi_selset_open_folder,
    ANIM_PT_yi_selset_popup,
    ANIM_PT_yi_selset_sidebar,
    ANIM_PT_yi_selset_strip_sidebar,
    ANIM_OT_yi_selset_strip_toggle,
    ANIM_OT_yi_selset_popup,
    ANIM_AP_yi_selset_prefs,
)


def register_keymaps():
    kc = bpy.context.window_manager.keyconfigs.addon
    if kc is None:  # background mode
        return
    km = kc.keymaps.new(name=KEYMAP_NAME, space_type='EMPTY')
    kmi = km.keymap_items.new(ANIM_OT_yi_selset_popup.bl_idname,
                              'Q', 'PRESS', shift=True)
    _addon_keymaps.append((km, kmi))


def unregister_keymaps():
    for km, kmi in _addon_keymaps:
        km.keymap_items.remove(kmi)
    _addon_keymaps.clear()


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    register_keymaps()
    migrate_old_storage()
    reload_cache()


def unregister():
    unregister_keymaps()
    restore_all_solo_states()
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    _cache.clear()
